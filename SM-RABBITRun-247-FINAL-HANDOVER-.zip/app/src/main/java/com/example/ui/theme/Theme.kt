package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HamstarDarkColorScheme = darkColorScheme(
  primary = GoldPrimary,
  onPrimary = DarkNavyBg,
  secondary = CyanAccent,
  onSecondary = DarkNavyBg,
  tertiary = GoldSecondary,
  background = DarkNavyBg,
  onBackground = TextWhite,
  surface = DarkCardSurface,
  onSurface = TextWhite,
  surfaceVariant = DarkCardVariant,
  onSurfaceVariant = TextMuted
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = HamstarDarkColorScheme,
    typography = Typography,
    content = content
  )
}
