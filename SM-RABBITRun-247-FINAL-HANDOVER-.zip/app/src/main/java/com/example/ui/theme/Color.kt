package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFFFC42E)
val GoldSecondary = Color(0xFFFF9F1C)
val CyanAccent = Color(0xFF00E5FF)
val DarkNavyBg = Color(0xFF0B0F1E)
val DarkCardSurface = Color(0xFF131A31)
val DarkCardVariant = Color(0xFF1B2442)
val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF9FB0D6)
