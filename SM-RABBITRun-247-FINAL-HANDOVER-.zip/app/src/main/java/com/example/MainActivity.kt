package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        HamstarProjectStudioApp()
      }
    }
  }
}

@Composable
fun HamstarProjectStudioApp() {
  var selectedTab by rememberSaveable { mutableIntStateOf(0) }
  val context = LocalContext.current

  BackHandler(enabled = selectedTab != 0) {
    selectedTab = 0
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    contentWindowInsets = WindowInsets.safeDrawing,
    bottomBar = {
      NavigationBar(
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface
      ) {
        NavigationBarItem(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Live Mini App") },
          label = { Text("Mini App") },
          modifier = Modifier.testTag("nav_mini_app")
        )
        NavigationBarItem(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          icon = { Icon(Icons.Default.Code, contentDescription = "HopWeb Code Files") },
          label = { Text("HopWeb Files") },
          modifier = Modifier.testTag("nav_files")
        )
        NavigationBarItem(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          icon = { Icon(Icons.Default.MenuBook, contentDescription = "Setup Guides") },
          label = { Text("Mobile Setup") },
          modifier = Modifier.testTag("nav_guides")
        )
        NavigationBarItem(
          selected = selectedTab == 3,
          onClick = { selectedTab = 3 },
          icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Testing Checklist") },
          label = { Text("Checklist") },
          modifier = Modifier.testTag("nav_checklist")
        )
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
    ) {
      when (selectedTab) {
        0 -> LiveMiniAppPreviewTab(context)
        1 -> HopWebFilesManagerTab(context)
        2 -> MobileSetupGuidesTab()
        3 -> FinalChecklistTab()
      }
    }
  }
}

@Composable
fun LiveMiniAppPreviewTab(context: Context) {
  val masterAds = remember {
    listOf(
      "🎬 YouTube Video Ad • Google Play" to "https://omg10.com/4/11690428",
      "📋 Quick Survey Ad • Consumer Poll" to "https://omg10.com/4/8272923",
      "🖼️ Full-Screen Banner • Samsung & Daraz" to "https://omg10.com/4/8272977",
      "✨ Sponsored Pop-up • bKash & Nagad" to "https://omg10.com/4/11690424",
      "⏭ Skippable Video Ad • Coursera & AI" to "https://omg10.com/4/11690425",
      "📋 Opinion Survey • Digital Wallet BD" to "https://omg10.com/4/8270886",
      "📢 Display Banner Ad • Spotify & Canva" to "https://omg10.com/4/8276769",
      "🖼️ Full-Screen Card • Cloudflare 1.1.1.1" to "https://omg10.com/4/8270889",
      "📋 Reward Survey • Smartphone Poll" to "https://omg10.com/4/8270887"
    )
  }

  val streakRewards = remember {
    listOf(100, 250, 450, 700, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 5000)
  }
  // 10 Boost Tiers: 300=1x (2h), 500=2x, 800=3x, 1100=4x, 1400=5x, 1800=6x, 2000=7x, 2200=8x, 3000=9x, 4000=10x
  val boostTiers = remember {
    listOf(
      300 to 1,
      500 to 2,
      800 to 3,
      1100 to 4,
      1400 to 5,
      1800 to 6,
      2000 to 7,
      2200 to 8,
      3000 to 9,
      4000 to 10
    )
  }
  fun getBoostCostAndMultiplier(buyIdx: Int): Pair<Int, Int> {
    val clamped = buyIdx.coerceIn(0, boostTiers.lastIndex)
    return boostTiers[clamped]
  }

  var useLiveHtmlWebView by rememberSaveable { mutableStateOf(true) }
  var pendingFileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
  val galleryPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    val cb = pendingFileCallback
    pendingFileCallback = null
    if (uri != null) {
      cb?.onReceiveValue(arrayOf(uri))
    } else {
      cb?.onReceiveValue(null)
    }
  }

  val prefs = remember {
    context.getSharedPreferences("sm_hamstar_isolated_users_v3", Context.MODE_PRIVATE)
  }
  val initialUid = remember {
    prefs.getString("last_active_mobile_uid", "01712345678") ?: "01712345678"
  }

  var mobileUserInput by rememberSaveable { mutableStateOf(initialUid) }
  var activeMobileUserId by rememberSaveable { mutableStateOf(initialUid) }
  var goldBalance by rememberSaveable {
    mutableIntStateOf(prefs.getInt("u_${initialUid}_gold", 0))
  }
  var diamondBalance by rememberSaveable {
    mutableStateOf(prefs.getFloat("u_${initialUid}_diamonds", 0f))
  }
  var convertedUsdBalance by rememberSaveable {
    mutableStateOf(prefs.getFloat("u_${initialUid}_usd", 0f))
  }
  var currentStreakDay by rememberSaveable {
    mutableIntStateOf(prefs.getInt("u_${initialUid}_streak", 1))
  }
  var dailyClaimedToday by rememberSaveable {
    mutableStateOf(prefs.getBoolean("u_${initialUid}_daily_claimed", false))
  }
  var showDailyModal by remember { mutableStateOf(false) }
  var twoFingerMode by rememberSaveable {
    mutableStateOf(prefs.getBoolean("u_${initialUid}_two_finger", false))
  }
  var multiStepCounter by rememberSaveable { mutableIntStateOf(0) }
  var lastStepLabel by rememberSaveable { mutableStateOf("+10") }
  var selectedSurveyChoice by remember { mutableStateOf("") }
  var boostBuysToday by rememberSaveable {
    mutableIntStateOf(prefs.getInt("u_${initialUid}_boost_buys", 0))
  }
  var boostSpeedPerMin by rememberSaveable {
    mutableIntStateOf(prefs.getInt("u_${initialUid}_boost_speed", 0))
  }
  var boostSecondsLeft by rememberSaveable {
    mutableIntStateOf(prefs.getInt("u_${initialUid}_boost_secs", 0))
  }
  var adminEmailInput by rememberSaveable { mutableStateOf("") }
  var adminPassInput by rememberSaveable { mutableStateOf("") }
  var isAdminLoggedIn by rememberSaveable { mutableStateOf(false) }
  val maxEnergy = 21500
  var energyFloat by rememberSaveable {
    mutableStateOf(prefs.getFloat("u_${initialUid}_energy_v2", maxEnergy.toFloat()))
  }
  // Without boost: 21,500 in 3 hours (10,800s). With 1x..10x boost: mult * (21,500 / 2 hours)
  val normalRegenPerSec = maxEnergy.toFloat() / 10800f
  val base1xRegenPerSec = maxEnergy.toFloat() / 7200f
  val activeRegenPerSec = if (boostSecondsLeft > 0 && boostSpeedPerMin >= 1) {
    base1xRegenPerSec * boostSpeedPerMin.coerceIn(1, 10)
  } else {
    normalRegenPerSec
  }
  var goldSliderFraction by rememberSaveable { mutableStateOf(1f) }
  var diamondSliderFraction by rememberSaveable { mutableStateOf(1f) }
  var showUsdCurrency by rememberSaveable { mutableStateOf(false) }
  var tapClickCount by rememberSaveable {
    mutableIntStateOf(prefs.getInt("u_${initialUid}_taps", 0))
  }
  val shownAdIndices = remember { mutableStateListOf<Int>() }
  var activeAdPair by remember { mutableStateOf<Pair<String, String>?>(null) }
  var adCountdownSec by remember { mutableIntStateOf(10) }
  var isDirect15SecMode by remember { mutableStateOf(false) }
  var isPressed by remember { mutableStateOf(false) }
  val scale by animateFloatAsState(targetValue = if (isPressed) 0.92f else 1f, label = "tap_scale")

  fun saveCurrentAccountState(uid: String = activeMobileUserId) {
    if (uid.length == 11 && uid.startsWith("01")) {
      prefs.edit()
        .putBoolean("u_${uid}_initialized", true)
        .putString("last_active_mobile_uid", uid)
        .putInt("u_${uid}_gold", goldBalance)
        .putFloat("u_${uid}_diamonds", diamondBalance)
        .putFloat("u_${uid}_usd", convertedUsdBalance)
        .putInt("u_${uid}_streak", currentStreakDay)
        .putBoolean("u_${uid}_daily_claimed", dailyClaimedToday)
        .putBoolean("u_${uid}_two_finger", twoFingerMode)
        .putInt("u_${uid}_boost_buys", boostBuysToday)
        .putInt("u_${uid}_boost_speed", boostSpeedPerMin)
        .putInt("u_${uid}_boost_secs", boostSecondsLeft)
        .putFloat("u_${uid}_energy_v2", energyFloat)
        .putInt("u_${uid}_taps", tapClickCount)
        .apply()
    }
  }

  fun switchOrLoadIsolatedUserAccount(targetUid: String): Boolean {
    // First save current user's progress under their own isolated key
    saveCurrentAccountState(activeMobileUserId)
    val existedBefore = prefs.getBoolean("u_${targetUid}_initialized", false)
    activeMobileUserId = targetUid
    if (existedBefore) {
      // Load existing user's saved account (never loses data)
      goldBalance = prefs.getInt("u_${targetUid}_gold", 0)
      diamondBalance = prefs.getFloat("u_${targetUid}_diamonds", 0f)
      convertedUsdBalance = prefs.getFloat("u_${targetUid}_usd", 0f)
      currentStreakDay = prefs.getInt("u_${targetUid}_streak", 1)
      dailyClaimedToday = prefs.getBoolean("u_${targetUid}_daily_claimed", false)
      twoFingerMode = prefs.getBoolean("u_${targetUid}_two_finger", false)
      boostBuysToday = prefs.getInt("u_${targetUid}_boost_buys", 0)
      boostSpeedPerMin = prefs.getInt("u_${targetUid}_boost_speed", 0)
      boostSecondsLeft = prefs.getInt("u_${targetUid}_boost_secs", 0)
      energyFloat = prefs.getFloat("u_${targetUid}_energy_v2", maxEnergy.toFloat())
      tapClickCount = prefs.getInt("u_${targetUid}_taps", 0)
    } else {
      // Brand-new account: start 100% from ZERO (no fake data, never mix with previous user)
      goldBalance = 0
      diamondBalance = 0f
      convertedUsdBalance = 0f
      currentStreakDay = 1
      dailyClaimedToday = false
      twoFingerMode = false
      multiStepCounter = 0
      lastStepLabel = "+10"
      boostBuysToday = 0
      boostSpeedPerMin = 0
      boostSecondsLeft = 0
      energyFloat = maxEnergy.toFloat()
      tapClickCount = 0
      shownAdIndices.clear()
    }
    saveCurrentAccountState(targetUid)
    return existedBefore
  }

  // Automatically persist every change for the active user ID immediately
  LaunchedEffect(
    activeMobileUserId,
    goldBalance,
    diamondBalance,
    convertedUsdBalance,
    currentStreakDay,
    dailyClaimedToday,
    twoFingerMode,
    boostBuysToday,
    boostSpeedPerMin,
    boostSecondsLeft,
     tapClickCount
  ) {
    saveCurrentAccountState(activeMobileUserId)
  }

  // Gradual 3-hour energy regeneration (21,500/3h) OR ⚡ Lightning Boost (1x..10x for 1 hour)
  LaunchedEffect(Unit) {
    while (true) {
      delay(1000)
      if (boostSecondsLeft > 0) {
        boostSecondsLeft -= 1
        if (boostSecondsLeft <= 0) {
          boostSpeedPerMin = 0
        }
      }
      val stepRegen = if (boostSecondsLeft > 0 && boostSpeedPerMin >= 1) {
        base1xRegenPerSec * boostSpeedPerMin.coerceIn(1, 10)
      } else {
        normalRegenPerSec
      }
      if (energyFloat < maxEnergy.toFloat()) {
        energyFloat = (energyFloat + stepRegen).coerceAtMost(maxEnergy.toFloat())
      }
    }
  }

  // 10-second Ad Countdown (or 15-second Direct Link Countdown) for Top-Right Cross (✕) & Skip Ad (⏭)
  LaunchedEffect(activeAdPair, isDirect15SecMode) {
    if (activeAdPair != null) {
      while (adCountdownSec > 0) {
        delay(1000)
        adCountdownSec -= 1
      }
    }
  }

  LaunchedEffect(isPressed) {
    if (isPressed) {
      delay(90)
      isPressed = false
    }
  }

  val adInterval = if (twoFingerMode) 50 else 10
  val clicksUntilAd = adInterval - (tapClickCount % adInterval)
  val availableClicks = energyFloat.toInt()
  val convertedBdtBalance = convertedUsdBalance * 125.0 // $1.00 USD = 125 ৳ BDT ($2.00 = 250 ৳)
  val nextBoostPair = getBoostCostAndMultiplier(boostBuysToday)
  val currentBoostMult = if (boostSecondsLeft > 0 && boostSpeedPerMin >= 1) boostSpeedPerMin.coerceIn(1, 10) else 0
  val currentBoostPerMin = ((maxEnergy / 120.0) * currentBoostMult).toInt()
  val nextBoostPerMin = ((maxEnergy / 120.0) * nextBoostPair.second).toInt()
  val formattedDiamonds = if (diamondBalance % 1f == 0f) {
    diamondBalance.toInt().toString()
  } else {
    "%.3f".format(diamondBalance).trimEnd('0').trimEnd('.')
  }

  // 12-Day Daily Streak Modal (Matches Screenshot 2: Day 1 = +1 💎 ... Day 12 = +12 💎 + Coins)
  if (showDailyModal) {
    val activeDay = ((currentStreakDay - 1) % streakRewards.size) + 1
    val todayCoinReward = streakRewards[activeDay - 1]
    val todayDiamondReward = activeDay

    AlertDialog(
      onDismissRequest = { showDailyModal = false },
      containerColor = Color(0xFF121930),
      title = {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "🎁 Daily Streak",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Log in daily to multiply your bonus coins!",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          for (rowIdx in 0 until 3) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              for (colIdx in 0 until 4) {
                val dayNum = rowIdx * 4 + colIdx + 1
                val coinAmt = streakRewards[dayNum - 1]
                val isClaimed = dayNum < activeDay || (dayNum == activeDay && dailyClaimedToday)
                val isActive = dayNum == activeDay && !dailyClaimedToday

                val borderColor = when {
                  isClaimed -> Color(0xFF18E08F)
                  isActive -> MaterialTheme.colorScheme.primary
                  else -> Color.White.copy(alpha = 0.14f)
                }
                val bgColor = when {
                  isClaimed -> Color(0xFF18E08F).copy(alpha = 0.14f)
                  isActive -> MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                  else -> Color.White.copy(alpha = 0.05f)
                }

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bgColor)
                    .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                    .clickable(enabled = isActive) {
                      goldBalance += coinAmt
                      diamondBalance += dayNum
                      dailyClaimedToday = true
                      currentStreakDay = (activeDay % streakRewards.size) + 1
                      showDailyModal = false
                      activeAdPair = masterAds.random()
                      adCountdownSec = 10
                      Toast.makeText(
                        context,
                        "🎁 Day $dayNum Claimed (+$coinAmt 🪙 & +$dayNum 💎)! ১০ সেকেন্ডের বিজ্ঞাপন চালু হয়েছে।",
                        Toast.LENGTH_SHORT
                      ).show()
                    }
                    .padding(vertical = 8.dp, horizontal = 4.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                      text = "Day $dayNum",
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                      text = "+$coinAmt",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                      text = "+$dayNum 💎",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = Color(0xFF38BDF8)
                    )
                  }
                }
              }
            }
          }
        }
      },
      confirmButton = {
        Column(modifier = Modifier.fillMaxWidth()) {
          Button(
            onClick = {
              if (!dailyClaimedToday) {
                goldBalance += todayCoinReward
                diamondBalance += todayDiamondReward
                dailyClaimedToday = true
                currentStreakDay = (activeDay % streakRewards.size) + 1
                showDailyModal = false
                activeAdPair = masterAds.random()
                adCountdownSec = 10
                Toast.makeText(
                  context,
                  "🎁 Claimed +$todayCoinReward Coins & +$todayDiamondReward 💎! ১০ সেকেন্ডের বিজ্ঞাপন চালু হয়েছে।",
                  Toast.LENGTH_SHORT
                ).show()
              }
            },
            enabled = !dailyClaimedToday,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = if (dailyClaimedToday) {
                "⏳ পরবর্তী ক্লেইম ২৪ ঘণ্টা পর জমবে"
              } else {
                "🎁 Claim Day $activeDay (+$todayCoinReward ★ & +$todayDiamondReward 💎)"
              },
              fontWeight = FontWeight.ExtraBold
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedButton(
            onClick = { showDailyModal = false },
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("🏠 হোমপেজে যান / Close", fontWeight = FontWeight.Bold)
          }
        }
      }
    )
  }

  if (activeAdPair != null) {
    val currentAd = activeAdPair!!
    val canCloseAd = adCountdownSec <= 0
    val isSurveyAd = currentAd.first.contains("Survey")
    AlertDialog(
      onDismissRequest = { /* Must wait 10s and click Cross (✕) or Skip Ad (⏭) */ },
      containerColor = MaterialTheme.colorScheme.surface,
      title = {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = currentAd.first,
              fontSize = 12.sp,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.primary
            )
            // Top-Right 10s Countdown -> Cross (✕) Button
            Button(
              onClick = {
                if (canCloseAd) {
                  diamondBalance += 1
                  if (isDirect15SecMode) {
                    goldBalance += 100
                    Toast.makeText(context, "💎 +1 Diamond & 🪙 +100 Gold Added!", Toast.LENGTH_SHORT).show()
                  } else {
                    Toast.makeText(context, "💎 +1 Diamond Reward Added!", Toast.LENGTH_SHORT).show()
                  }
                  activeAdPair = null
                  isDirect15SecMode = false
                  selectedSurveyChoice = ""
                }
              },
              enabled = canCloseAd,
              colors = ButtonDefaults.buttonColors(
                containerColor = if (canCloseAd) Color(0xFFFF4D6D) else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = Color.White
              ),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
              modifier = Modifier.testTag("ad_cross_close_button")
            ) {
              Text(
                text = if (canCloseAd) {
                  if (isDirect15SecMode) "✕ Claim +1 💎 +100 🪙" else "✕ Claim +1 💎"
                } else {
                  "⏳ ${adCountdownSec}s"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold
              )
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "YouTube / VidMate Safe Ad (${shownAdIndices.size}/${masterAds.size})",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }
      },
      text = {
        Column {
          Text(
            text = if (canCloseAd) {
              "✅ ১০ সেকেন্ড পূর্ণ হয়েছে! Skip Ad ⏭ অথবা উপরের ✕ চিহ্নে ক্লিক করলে +1 💎 ডায়মন্ড যোগ হবে।"
            } else {
              "⏳ নিরাপদ বিজ্ঞাপন চলছে... ${adCountdownSec} সেকেন্ড পর Skip Ad ⏭ ও ✕ (ক্রস) চিহ্ন চালু হবে!"
            },
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(10.dp))
          Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0E162B)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f), RoundedCornerShape(14.dp))
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "🛡️ 100% Family-Safe Verified (No Adult / No Scam)",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF18E08F)
              )
              Spacer(modifier = Modifier.height(6.dp))
              if (isSurveyAd) {
                Text(
                  text = "📋 ১-ক্লিক সার্ভে: আপনার পছন্দের অ্যাপ বা মাধ্যম কোনটি?",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                listOf("🎬 YouTube / VidMate", "📱 Facebook / Telegram", "📲 bKash / Nagad / USDT").forEach { opt ->
                  OutlinedButton(
                    onClick = { selectedSurveyChoice = opt },
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                  ) {
                    Text(
                      text = if (selectedSurveyChoice == opt) "✅ $opt" else opt,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                }
              } else {
                Text(
                  text = "▶ ${currentAd.first}",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "YouTube, VidMate & Facebook style clean video/banner showcase.",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "${(10 - adCountdownSec.coerceIn(0, 10)) * 10}% watched",
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.secondary
                )
                Button(
                  onClick = {
                    if (canCloseAd) {
                      diamondBalance += 1
                      if (isDirect15SecMode) goldBalance += 100
                      Toast.makeText(context, "💎 +1 Diamond Reward Added!", Toast.LENGTH_SHORT).show()
                      activeAdPair = null
                      isDirect15SecMode = false
                      selectedSurveyChoice = ""
                    }
                  },
                  enabled = canCloseAd,
                  contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                  Text(
                    text = if (canCloseAd) "Skip Ad ⏭ (+1 💎)" else "Skip Ad in ${adCountdownSec}s ⏭",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                  )
                }
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val url = currentAd.second
            isDirect15SecMode = true
            adCountdownSec = 15
            try {
              context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {}
          }
        ) {
          Text("🚀 Open Verified Sponsor (15s = +1 💎 & +100 🪙)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
      }
    )
  }

  val isRobolectric = remember { android.os.Build.FINGERPRINT.contains("robolectric", ignoreCase = true) }
  var showFullWebView by remember { mutableStateOf(!isRobolectric) }

  if (showFullWebView) {
    Column(modifier = Modifier.fillMaxSize()) {
      Surface(
        color = Color(0xFF0B0F1E),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "🟢 SM HAMSTAR BOT 247 (Live Mini App)",
              fontWeight = FontWeight.ExtraBold,
              fontSize = 12.sp,
              color = Color(0xFFFFC42E)
            )
          }
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            OutlinedButton(
              onClick = { showFullWebView = false },
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 3.dp),
              modifier = Modifier.testTag("switch_to_native_button")
            ) {
              Text("🛠️ Native View", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      AndroidView(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        factory = { ctx ->
          WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            @Suppress("DEPRECATION")
            settings.allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            settings.allowUniversalAccessFromFileURLs = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
              override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
              ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                galleryPickerLauncher.launch("image/*")
                return true
              }
            }
            loadUrl("file:///android_asset/SM-HAMSTAR-BOT-247/index.html")
          }
        }
      )
    }
    return
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
  ) {
    // Top Header Bar
    Surface(
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(
            text = "SM HAMSTAR BOT 247",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "⚡ 21,500 Energy • 1×..10× Boost • 💎 Safe Video/Survey Ads",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Button(
            onClick = { showFullWebView = true },
            colors = ButtonDefaults.buttonColors(
              containerColor = Color(0xFF18E08F),
              contentColor = Color(0xFF042214)
            ),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.testTag("open_full_webview_button")
          ) {
            Text("🌐 Live Mini App", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
          }
          OutlinedButton(
            onClick = {
              dailyClaimedToday = false
              showDailyModal = true
            },
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.testTag("open_daily_streak_button")
          ) {
            Text("🎁 Daily", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
          Button(
            onClick = {
              val html = readAssetText(context, "SM-HAMSTAR-BOT-247/index.html")
              copyToClipboard(context, "index.html", html)
            },
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.testTag("quick_copy_index_button")
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = "Copy index.html", modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Copy HTML", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          IconButton(
            onClick = {
              saveCurrentAccountState(activeMobileUserId)
              Toast.makeText(
                context,
                "🔄 আইডি #$activeMobileUserId এর সকল ডাটা অক্ষত ও লাইভ সেভ রয়েছে!",
                Toast.LENGTH_SHORT
              ).show()
            },
            modifier = Modifier.testTag("reload_webview_button")
          ) {
            Icon(Icons.Default.Refresh, contentDescription = "Sync Saved Data")
          }
        }
      }
    }

    // Top Scrolling News Marquee Bar
    Surface(
      color = Color(0xFF0E162B),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp)
        .clip(RoundedCornerShape(999.dp))
        .border(1.dp, Color(0xFFFFC42E).copy(alpha = 0.35f), RoundedCornerShape(999.dp))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0xFFFF4D6D))
            .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Text("📰 NEWS", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.White)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "🔥 SM HAMSTAR BOT 247: 21,500 Energy (3h Normal / 2h 1×..10× Boost) • 2,000 Gold = 1 💎 • 10,000 💎 = $1.00 (125৳)!",
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          color = Color(0xFFFDE68A),
          maxLines = 1
        )
      }
    }

    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // 3 Stat Cards
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        StatMiniCard(
          title = "TAP GOLD",
          value = if (twoFingerMode) "+2 ★" else "+1 ★",
          modifier = Modifier.weight(1f)
        )
        StatMiniCard(title = "NEXT AD IN", value = "$clicksUntilAd Taps", modifier = Modifier.weight(1f))
        StatMiniCard(title = "AD REWARD", value = "+1 💎", modifier = Modifier.weight(1f))
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Blue Diamond Balance + Converted Main Balance Card + Green Conversion Sliders
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f), RoundedCornerShape(18.dp))
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                  .size(38.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color(0xFF38BDF8).copy(alpha = 0.2f))
              ) {
                Text("💎", fontSize = 18.sp)
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("DIAMONDS (💎)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$formattedDiamonds 💎", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFF38BDF8))
              }
            }
            Column(horizontalAlignment = Alignment.End) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("মেইন ব্যালেন্স (Min: $2 / 250৳)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(
                  onClick = { showUsdCurrency = !showUsdCurrency },
                  contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(if (!showUsdCurrency) "৳ BDT" else "$ USD", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                }
              }
              if (!showUsdCurrency) {
                Text("৳${"%.2f".format(convertedBdtBalance)}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF18E08F))
                Text("$${"%.2f".format(convertedUsdBalance)} USD (1$ = 125৳)", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
              } else {
                Text("$${"%.2f".format(convertedUsdBalance)} USD", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF18E08F))
                Text("৳${"%.2f".format(convertedBdtBalance)} BDT (1$ = 125৳)", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Green Slider 1: Gold -> Diamond (2,000 Gold = 1 Diamond)
          val selectedGoldToConvert = (goldBalance * goldSliderFraction).toInt()
          val previewDiamondOut = selectedGoldToConvert / 2000f
          Text(
            text = "🪙 গোল্ড ➔ 💎 ডায়মন্ড স্লাইডার: $selectedGoldToConvert 🪙 = +${"%.3f".format(previewDiamondOut)} 💎 (${(goldSliderFraction * 100).toInt()}%)",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF18E08F)
          )
          Slider(
            value = goldSliderFraction,
            onValueChange = { goldSliderFraction = it },
            colors = SliderDefaults.colors(
              thumbColor = Color(0xFF18E08F),
              activeTrackColor = Color(0xFF18E08F),
              inactiveTrackColor = Color(0xFF18E08F).copy(alpha = 0.24f)
            ),
            modifier = Modifier.fillMaxWidth()
          )

          // Green Slider 2: Diamond -> USD / BDT (10,000 Diamond = $1.00 = 125 BDT)
          val selectedDiaToConvert = diamondBalance * diamondSliderFraction
          val previewUsdOut = selectedDiaToConvert * 0.0001f
          val previewBdtOut = previewUsdOut * 125f
          Text(
            text = "💎 ডায়মন্ড ➔ মেইন ব্যালেন্স স্লাইডার: ${"%.2f".format(selectedDiaToConvert)} 💎 = +$${"%.4f".format(previewUsdOut)} / ৳${"%.2f".format(previewBdtOut)} (${(diamondSliderFraction * 100).toInt()}%)",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF18E08F)
          )
          Slider(
            value = diamondSliderFraction,
            onValueChange = { diamondSliderFraction = it },
            colors = SliderDefaults.colors(
              thumbColor = Color(0xFF18E08F),
              activeTrackColor = Color(0xFF18E08F),
              inactiveTrackColor = Color(0xFF18E08F).copy(alpha = 0.24f)
            ),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = {
                val convGold = (goldBalance * goldSliderFraction).toInt()
                if (convGold < 10) {
                  Toast.makeText(context, "🪙 ডায়মন্ডে কনভার্ট করতে কমপক্ষে ১০ গোল্ড কয়েন প্রয়োজন!", Toast.LENGTH_SHORT).show()
                } else {
                  val addedDiamonds = convGold / 2000f
                  goldBalance -= convGold
                  diamondBalance += addedDiamonds
                  Toast.makeText(
                    context,
                    "✅ $convGold 🪙 গোল্ড কনভার্ট হয়ে +${"%.3f".format(addedDiamonds).trimEnd('0').trimEnd('.')} 💎 ডায়মন্ড হয়েছে!",
                    Toast.LENGTH_SHORT
                  ).show()
                }
              },
              modifier = Modifier.weight(1f),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text("🔄 🪙 গোল্ড ➔ 💎 ডায়মন্ড", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Button(
              onClick = {
                val convDia = diamondBalance * diamondSliderFraction
                if (convDia <= 0f) {
                  Toast.makeText(context, "💎 ব্যালেন্সে কনভার্ট করার মতো ডায়মন্ড নেই!", Toast.LENGTH_SHORT).show()
                } else {
                  val addedUsd = convDia * 0.0001f
                  val addedBdt = addedUsd * 125f
                  diamondBalance = (diamondBalance - convDia).coerceAtLeast(0f)
                  convertedUsdBalance += addedUsd
                  Toast.makeText(
                    context,
                    "✅ ${"%.2f".format(convDia)} 💎 কনভার্ট হয়ে ব্যালেন্সে +৳${"%.2f".format(addedBdt)} ($${"%.4f".format(addedUsd)}) যোগ হয়েছে!",
                    Toast.LENGTH_SHORT
                  ).show()
                }
              },
              modifier = Modifier.weight(1f),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text("🔄 💎 ডায়মন্ড ➔ 💰 ব্যালেন্স", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Gold / Tap Coin Balance OUTSIDE Directly Above Tap Circle
      Text(
        text = "VERIFIED GOLD BALANCE",
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(4.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(
              Brush.radialGradient(
                colors = listOf(Color(0xFFFFE680), Color(0xFFFFAE00))
              )
            )
        ) {
          Text(
            text = "★",
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            color = Color(0xFF3A2300)
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "%,d".format(goldBalance),
          fontSize = 38.sp,
          fontWeight = FontWeight.Black,
          color = Color.White
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      // 1-Finger vs 2-Finger Mode Selector
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = {
            twoFingerMode = false
            multiStepCounter = 0
            lastStepLabel = "+1"
          },
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = if (!twoFingerMode) "✅ 👆 ১ আঙুল (১০ ক্লিকে অ্যাড)" else "👆 ১ আঙুল (১০ ক্লিকে অ্যাড)",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
          )
        }
        OutlinedButton(
          onClick = {
            twoFingerMode = true
          },
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = if (twoFingerMode) "✅ ✌️ ২ আঙুল (৫০ ক্লিকে অ্যাড)" else "✌️ ২ আঙুল (৫০ ক্লিকে অ্যাড)",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Interactive Tap Button
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(215.dp)
          .scale(scale)
          .clip(CircleShape)
          .background(
            Brush.radialGradient(
              colors = listOf(
                MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                MaterialTheme.colorScheme.surface
              )
            )
          )
          .border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
          .clickable {
            if (availableClicks < 1) {
              Toast.makeText(context, "⚡ ২১,৫০০ এনার্জি শেষ! ৩ ঘণ্টায় (অথবা বুস্টে ২ ঘণ্টায়) রিচার্জ হচ্ছে...", Toast.LENGTH_SHORT).show()
              return@clickable
            }
            isPressed = true
            val clicksThisTap = if (twoFingerMode) 2.coerceAtMost(availableClicks) else 1
            var triggerAdNow = false
            repeat(clicksThisTap) {
              goldBalance += 1
              energyFloat = (energyFloat - 1f).coerceAtLeast(0f)
              tapClickCount += 1
              lastStepLabel = if (twoFingerMode) "+2" else "+1"
              if (tapClickCount % adInterval == 0) {
                triggerAdNow = true
              }
            }

            if (triggerAdNow) {
              val unseen = masterAds.indices.filter { it !in shownAdIndices }
              if (unseen.isNotEmpty()) {
                val chosenIdx = unseen.random()
                shownAdIndices.add(chosenIdx)
                isDirect15SecMode = false
                adCountdownSec = 10
                activeAdPair = masterAds[chosenIdx]
              } else {
                Toast.makeText(
                  context,
                  "✅ সবগুলো ইউনিক বিজ্ঞাপন ১ বার করে দেখানো সম্পন্ন হয়েছে!",
                  Toast.LENGTH_SHORT
                ).show()
              }
            }
          }
          .testTag("hamstar_tap_button")
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_app_icon_1790445190121),
          contentDescription = "Tap to Earn +1",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
            .clip(CircleShape)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Energy Card (21,500 Energy: 3 Hours Normal / 2 Hours with 300=1x .. 4000=10x Boost)
      val missingClicks = (maxEnergy.toFloat() - energyFloat).coerceAtLeast(0f)
      val secsLeft = (missingClicks / activeRegenPerSec).toInt()
      val hrsLeft = secsLeft / 3600
      val minsLeft = (secsLeft % 3600) / 60
      val remSecs = secsLeft % 60
      val boostM = boostSecondsLeft / 60
      val boostS = boostSecondsLeft % 60

      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedButton(
              onClick = {
                val (cost, mult) = getBoostCostAndMultiplier(boostBuysToday)
                val speedPerMin = ((maxEnergy / 120.0) * mult).toInt()
                if (goldBalance < cost) {
                  Toast.makeText(
                    context,
                    "⚡ ${mult}× এনার্জি বুস্ট কিনতে $cost 🪙 গোল্ড প্রয়োজন! (গতি: +$speedPerMin/মিনিট)",
                    Toast.LENGTH_SHORT
                  ).show()
                } else {
                  goldBalance -= cost
                  boostBuysToday += 1
                  boostSpeedPerMin = mult
                  boostSecondsLeft = 7200 // 2 Hours
                  val (nextCost, nextMult) = getBoostCostAndMultiplier(boostBuysToday)
                  Toast.makeText(
                    context,
                    "⚡ -$cost 🪙! ${mult}× বুস্ট চালু (+$speedPerMin/মিনিট)। পরবর্তী বুস্ট: $nextCost🪙=${nextMult}×",
                    Toast.LENGTH_SHORT
                  ).show()
                }
              },
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Text(
                text = if (boostSecondsLeft > 0) {
                  "⚡ ${currentBoostMult}× বুস্ট (+$currentBoostPerMin/m • ${boostM}m ${boostS}s) | Next: ${nextBoostPair.first}🪙=${nextBoostPair.second}×"
                } else {
                  "⚡ বুস্ট: ${nextBoostPair.first} 🪙 = ${nextBoostPair.second}× (+$nextBoostPerMin/m)"
                },
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
              )
            }
            Text("⚡ $availableClicks / $maxEnergy", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = if (availableClicks >= maxEnergy) {
                if (boostSecondsLeft > 0) "⚡ 21,500 Energy Full (${currentBoostMult}× Boost)" else "✅ 21,500 Energy Ready (Normal: 3h Full)"
              } else if (boostSecondsLeft > 0) {
                "⚡ ${currentBoostMult}× বুস্ট (+$currentBoostPerMin/m) • Full in ${hrsLeft}h ${minsLeft}m ${remSecs}s"
              } else {
                "⏳ Normal (3h = 21,500) • Full in ${hrsLeft}h ${minsLeft}m ${remSecs}s"
              },
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = "Step: $lastStepLabel 🪙",
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.primary
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "⚡ বুস্ট: বিনা বুস্টে ৩ ঘণ্টায় ২১,৫০০ • 300=1× (২ ঘণ্টায়) • 500=2× • 800=3× • 1100=4× • 1400=5× • 1800=6× • 2000=7× • 2200=8× • 3000=9× • 4000=10×",
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.secondary
          )
          Spacer(modifier = Modifier.height(8.dp))
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(10.dp)
              .clip(RoundedCornerShape(999.dp))
              .background(Color.White.copy(alpha = 0.12f))
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth(fraction = (energyFloat / maxEnergy.toFloat()).coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(
                  Brush.horizontalGradient(
                    listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)
                  )
                )
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Total Clicks: $tapClickCount • Ads Shown: ${shownAdIndices.size}/${masterAds.size}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Separate Admin Panel Login & Control Card (smarafat113rt@gmail.com ONLY)
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.35f), RoundedCornerShape(16.dp))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "🛡️ আলাদা অ্যাডমিন প্যানেল কন্ট্রোল",
              fontSize = 13.sp,
              fontWeight = FontWeight.ExtraBold,
              color = Color(0xFF38BDF8)
            )
            Text(
              text = if (isAdminLoggedIn) "🟢 Logged In" else "🔒 Email/Pass Gate",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = if (isAdminLoggedIn) Color(0xFF18E08F) else Color(0xFFFF9F1C)
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          if (!isAdminLoggedIn) {
            Text(
              text = "শুধুমাত্র smarafat113rt@gmail.com ইমেইল ও পাসওয়ার্ড দিয়ে অ্যাডমিন প্যানেলে ঢোকা যাবে:",
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
              value = adminEmailInput,
              onValueChange = { adminEmailInput = it },
              label = { Text("Admin Email", fontSize = 10.sp) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = adminPassInput,
              onValueChange = { adminPassInput = it },
              label = { Text("Admin Password", fontSize = 10.sp) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              OutlinedButton(
                onClick = {
                  adminEmailInput = "smarafat113rt@gmail.com"
                  adminPassInput = "smarafat113rt@gmail.com"
                },
                modifier = Modifier.weight(1f)
              ) {
                Text("Fill Admin", fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
              Button(
                onClick = {
                  if (
                    adminEmailInput.trim().lowercase() == "smarafat113rt@gmail.com" &&
                    adminPassInput.trim() == "smarafat113rt@gmail.com"
                  ) {
                    isAdminLoggedIn = true
                    Toast.makeText(context, "✅ অ্যাডমিন প্যানেলে লগইন সফল!", Toast.LENGTH_SHORT).show()
                  } else {
                    Toast.makeText(context, "🚫 ভুল জিমেইল বা পাসওয়ার্ড!", Toast.LENGTH_SHORT).show()
                  }
                },
                modifier = Modifier.weight(1f)
              ) {
                Text("🔐 Login Admin", fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
          } else {
            Text(
              text = "টার্গেট মোবাইল ইউজার আইডি: #$activeMobileUserId (sm-rabbit-247)",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              OutlinedButton(
                onClick = {
                  goldBalance += 1000
                  Toast.makeText(context, "🛡️ Admin: +1,000 🪙 Gold (#$activeMobileUserId) যোগ হয়েছে!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 6.dp, horizontal = 4.dp)
              ) {
                Text("+1,000 🪙", fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
              OutlinedButton(
                onClick = {
                  diamondBalance += 10f
                  Toast.makeText(context, "🛡️ Admin: +10 💎 Diamond (#$activeMobileUserId) যোগ হয়েছে!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 6.dp, horizontal = 4.dp)
              ) {
                Text("+10 💎", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
              }
              OutlinedButton(
                onClick = {
                  convertedUsdBalance += 2f
                  Toast.makeText(context, "🛡️ Admin: +$2.00 (220.00 ৳) মেইন ব্যালেন্সে যোগ হয়েছে!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 6.dp, horizontal = 4.dp)
              ) {
                Text("+$2.00 (220৳)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF18E08F))
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun StatMiniCard(title: String, value: String, modifier: Modifier = Modifier) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    shape = RoundedCornerShape(14.dp),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 10.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = title,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = FontWeight.SemiBold
      )
      Spacer(modifier = Modifier.height(3.dp))
      Text(
        text = value,
        fontSize = 14.sp,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}

@Composable
fun HopWebFilesManagerTab(context: Context) {
  val fileNames = listOf(
    "index.html",
    "worker.js",
    "README.md",
    "Firebase Rules",
    "Firebase Schema"
  )
  var selectedFileIndex by rememberSaveable { mutableIntStateOf(0) }

  val currentFileContent = remember(selectedFileIndex) {
    when (selectedFileIndex) {
      0 -> readAssetText(context, "SM-HAMSTAR-BOT-247/index.html")
      1 -> readAssetText(context, "SM-HAMSTAR-BOT-247/worker.js")
      2 -> readAssetText(context, "SM-HAMSTAR-BOT-247/README.md")
      3 -> FIREBASE_RULES_JSON
      else -> FIREBASE_STRUCTURE_JSON
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Folder Structure Card
    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Folder,
            contentDescription = "Folder Structure",
            tint = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "One-Folder Rule: SM-HAMSTAR-BOT-247/",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "├── index.html (Complete Frontend)\n├── worker.js (Cloudflare Worker API)\n├── README.md\n└── assets/\n    ├── background.png\n    └── tap-button.png",
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // File Selector Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      fileNames.forEachIndexed { index, name ->
        FilterChip(
          selected = selectedFileIndex == index,
          onClick = { selectedFileIndex = index },
          label = { Text(name, fontWeight = FontWeight.SemiBold) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
          ),
          modifier = Modifier.testTag("file_chip_$index")
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Copy Complete File Button for HopWeb
    Button(
      onClick = {
        copyToClipboard(context, fileNames[selectedFileIndex], currentFileContent)
      },
      colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary
      ),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
        .testTag("copy_complete_file_button")
    ) {
      Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "Copy Complete ${fileNames[selectedFileIndex]} for HopWeb",
        fontWeight = FontWeight.ExtraBold
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Full Code Viewer
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .clip(RoundedCornerShape(14.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
        .padding(12.dp)
        .verticalScroll(rememberScrollState())
    ) {
      Text(
        text = currentFileContent,
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

@Composable
fun MobileSetupGuidesTab() {
  val guides = remember {
    listOf(
      GuideSection(
        "1. HopWeb Android Setup",
        listOf(
          "Open HopWeb on your Android phone and tap '+' to create a new project folder named SM-HAMSTAR-BOT-247.",
          "Inside SM-HAMSTAR-BOT-247, create a subfolder named assets.",
          "Upload your main background image into assets/background.png and your tap button image into assets/tap-button.png.",
          "Open index.html in HopWeb, erase any template text, and paste the complete index.html code from <!DOCTYPE html> to </html>.",
          "Publish or host the frontend from HopWeb (or GitHub Pages / Cloudflare Pages direct folder upload from mobile browser) to get your HTTPS URL."
        )
      ),
      GuideSection(
        "2. Firebase Realtime Database (Mobile Browser)",
        listOf(
          "Open console.firebase.google.com in Chrome on Android, create a project, and open Build -> Realtime Database.",
          "Tap Create Database, choose a region, and copy your Database URL (e.g. https://your-project-default-rtdb.firebaseio.com).",
          "Open the Rules tab, paste the locked server-only Firebase Rules (.read: false, .write: false), and tap Publish.",
          "Tap the Project Settings gear icon -> Service accounts -> Database secrets, and copy your Database Secret for Cloudflare Worker."
        )
      ),
      GuideSection(
        "3. Cloudflare Worker Setup (Mobile Browser)",
        listOf(
          "Log in to dash.cloudflare.com on your Android browser -> Workers & Pages -> Create Worker.",
          "Name your worker sm-hamstar-bot-247 and tap Deploy, then tap Edit Code.",
          "Delete the default snippet, paste the complete worker.js file, and tap Deploy.",
          "Go to Worker Settings -> Variables and Secrets, and add: BOT_TOKEN, FIREBASE_DB_URL, FIREBASE_DB_SECRET, ADMIN_TELEGRAM_IDS, and MINI_APP_URL."
        )
      ),
      GuideSection(
        "4. Telegram Bot Setup (@BotFather)",
        listOf(
          "Open @BotFather in Telegram on Android and send /newbot to create your bot and receive your BOT_TOKEN.",
          "Send /newapp or /setmenubutton to @BotFather, select your bot, and enter your HTTPS index.html URL.",
          "In your mobile browser, visit: https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook?url=https://<YOUR_WORKER_URL>/webhook",
          "Open your Mini App on Telegram, tap the ⚙️ icon in the top-right, and save your Cloudflare Worker URL and Bot Username."
        )
      )
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          Icons.Default.Security,
          contentDescription = "Security",
          tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "100% Android Phone Workflow",
          fontSize = 18.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
      Text(
        text = "No PC, Node.js, npm, Vite, or terminal required.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    items(guides) { section ->
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = section.title,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.height(8.dp))
          section.steps.forEachIndexed { idx, step ->
            Text(
              text = "${idx + 1}. $step",
              fontSize = 13.sp,
              lineHeight = 19.sp,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(vertical = 3.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
fun FinalChecklistTab() {
  val checklistItems = remember {
    listOf(
      "assets/background.png and assets/tap-button.png placed inside SM-HAMSTAR-BOT-247/assets/",
      "index.html contains zero secret keys (no BOT_TOKEN or FIREBASE_DB_SECRET)",
      "Firebase Realtime Database rules locked to .read: false and .write: false",
      "Cloudflare Worker deployed with BOT_TOKEN and FIREBASE_DB_SECRET secrets",
      "Telegram initData HMAC-SHA256 verification passing on /api/auth",
      "Tap earning deducts energy and syncs verified balance to Firebase",
      "Daily streak claim enforces 24-hour server cooldown",
      "Tasks verify completion and prevent duplicate claims",
      "Referral link (?startapp=ref_ID) credits +250 coins to referrer",
      "Withdrawal request deducts balance and appears in Admin Panel queue"
    )
  }
  val checkedState = remember {
    mutableStateListOf(*Array(checklistItems.size) { false })
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Text(
        text = "Final Deployment Checklist",
        fontSize = 18.sp,
        fontWeight = FontWeight.ExtraBold
      )
      Text(
        text = "Tap each item as you verify your live Telegram Mini App on Android.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    items(checklistItems.indices.toList()) { index ->
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { checkedState[index] = !checkedState[index] }
          .testTag("checklist_item_$index")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Checkbox(
            checked = checkedState[index],
            onCheckedChange = { checkedState[index] = it }
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = checklistItems[index],
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }
  }
}

data class GuideSection(val title: String, val steps: List<String>)

private fun readAssetText(context: Context, path: String): String {
  return try {
    context.assets.open(path).bufferedReader().use { it.readText() }
  } catch (e: Exception) {
    "Unable to load asset: $path (${e.message})"
  }
}

private fun copyToClipboard(context: Context, label: String, content: String) {
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  clipboard.setPrimaryClip(ClipData.newPlainText(label, content))
  Toast.makeText(context, "Copied complete $label to clipboard!", Toast.LENGTH_SHORT).show()
}

private const val FIREBASE_RULES_JSON = """{
  "rules": {
    ".read": false,
    ".write": false,
    "users": {
      ".indexOn": ["balance", "diamonds", "usdBalance", "referralCount", "createdAt"]
    },
    "withdrawals": {
      ".indexOn": ["status", "userId", "createdAt"]
    }
  }
}"""

private const val FIREBASE_STRUCTURE_JSON = """{
  "firebaseProject": {
    "projectId": "sm-rabbit-247",
    "databaseURL": "https://sm-rabbit-247-default-rtdb.firebaseio.com",
    "appId": "1:641287161248:web:17403a2fc0b7fa87f4138d"
  },
  "config": {
    "minWithdrawUsd": 2,
    "minWithdrawBdt": 220,
    "usdToBdtRate": 110,
    "maintenance": false,
    "announcement": "Welcome to SM HAMSTAR BOT 247! Tap to earn & invite friends."
  },
  "tasks": [
    {
      "id": "join_channel",
      "title": "Join Official Telegram Channel",
      "reward": 500,
      "url": "https://t.me/Telegram",
      "chatId": "",
      "type": "telegram"
    }
  ],
  "users": {
    "123456789": {
      "id": "123456789",
      "firstName": "Hamstar Player",
      "username": "hamstar247",
      "balance": 350,
      "totalEarned": 350,
      "totalTaps": 100,
      "energy": 480,
      "maxEnergy": 500,
      "tapPower": 1,
      "streak": 2,
      "lastDailyClaim": 1758880000000,
      "lastEnergyAt": 1758880050000,
      "lastTapSyncAt": 1758880050000,
      "referralCount": 1,
      "referralEarnings": 250,
      "referredBy": null,
      "isBanned": false,
      "createdAt": 1758800000000
    }
  },
  "userTasks": {
    "123456789": {
      "join_channel": 1758880020000
    }
  },
  "referrals": {
    "123456789": {
      "987654321": {
        "id": "987654321",
        "name": "Friend User",
        "bonus": 250,
        "createdAt": 1758880010000
      }
    }
  },
  "withdrawals": {
    "wd_1758880090000_123456789": {
      "id": "wd_1758880090000_123456789",
      "userId": "123456789",
      "userName": "Hamstar Player",
      "method": "USDT_TRC20",
      "account": "TXXXXXXXXXXXXXXXXXXXX",
      "amount": 1000,
      "status": "pending",
      "createdAt": 1758880090000
    }
  },
  "transactions": {
    "123456789": {
      "wd_1758880090000_123456789": {
        "id": "wd_1758880090000_123456789",
        "type": "withdrawal",
        "method": "USDT_TRC20",
        "account": "TXXXXXXXXXXXXXXXXXXXX",
        "amount": 1000,
        "status": "pending",
        "createdAt": 1758880090000
      }
    }
  }
}"""
